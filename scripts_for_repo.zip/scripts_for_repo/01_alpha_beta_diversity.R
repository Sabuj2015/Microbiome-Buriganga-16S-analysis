# 01_alpha_beta_diversity.R
# This script performs alpha and beta diversity analyses for the Buriganga-Turag microbiome study.
# Includes: Alpha diversity indices, Kruskal-Wallis & Dunn's post-hoc tests, PERMDISP, PERMANOVA, and PCoA.

library(phyloseq)
library(vegan)
library(ggplot2)
library(dunn.test)
library(dplyr)

# 1. Load Data
# Assuming OTU_Table.csv has OTUs as rows and Samples as columns, with Taxonomy in the last column
otu_data <- read.csv("Buriganga_Turag_16S_OTU_Taxonomy_Counts.csv", row.names = 1)
tax_data <- otu_data[, "Taxonomy", drop = FALSE]
otu_counts <- otu_data[, -ncol(otu_data)]

# Create phyloseq object
OTU <- otu_table(as.matrix(otu_counts), taxa_are_rows = TRUE)
# Parse taxonomy (simplified for this script, assuming semicolon separated)
tax_matrix <- do.call(rbind, strsplit(as.character(tax_data$Taxonomy), ";"))
colnames(tax_matrix) <- c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")
rownames(tax_matrix) <- rownames(tax_data)
TAX <- tax_table(tax_matrix)

# Create metadata based on sample names
samples <- colnames(otu_counts)
metadata <- data.frame(
  SampleID = samples,
  Habitat = ifelse(grepl("W$", samples), "Water", "Sediment"),
  Zone = case_when(
    grepl("^(Deul|Nbb|Abb)", samples) ~ "Upstream",
    grepl("^(Bsb|Mdc|Krc|Bsg|Jjf|Bbb)", samples) ~ "Midstream",
    grepl("^(Cmb|Pgb|Hnb|Pagla|Fatul)", samples) ~ "Downstream"
  )
)
rownames(metadata) <- metadata$SampleID
META <- sample_data(metadata)

physeq <- phyloseq(OTU, TAX, META)

# 2. Alpha Diversity
alpha_div <- estimate_richness(physeq, measures = c("Observed", "Chao1", "Shannon", "Simpson"))
alpha_div$Habitat <- sample_data(physeq)$Habitat
alpha_div$Zone <- sample_data(physeq)$Zone
alpha_div$Group <- paste(alpha_div$Zone, alpha_div$Habitat, sep="_")

# Statistical testing (Sediment vs Water)
cat("\n--- Alpha Diversity: Kruskal-Wallis (Habitat) ---\n")
kruskal.test(Shannon ~ Habitat, data = alpha_div)

# Statistical testing across Zones (Dunn's post-hoc)
cat("\n--- Alpha Diversity: Dunn's Test (Zone/Habitat groups) ---\n")
dunn.test(alpha_div$Shannon, g = alpha_div$Group, method = "bh")

# 3. Beta Diversity (Bray-Curtis & UniFrac)
# (Note: UniFrac requires a phylogenetic tree. Using Bray-Curtis here as proxy for compositional differences)
dist_bc <- distance(physeq, method = "bray")

# PERMDISP (Dispersion)
cat("\n--- PERMDISP (Habitat) ---\n")
disp_habitat <- betadisper(dist_bc, sample_data(physeq)$Habitat)
print(anova(disp_habitat))
permutest(disp_habitat, permutations = 999)

# PERMANOVA
cat("\n--- PERMANOVA (Habitat and Zone) ---\n")
adonis2(dist_bc ~ Habitat * Zone, data = as(sample_data(physeq), "data.frame"), permutations = 999)

# PCoA Plot
pcoa_bc <- ordinate(physeq, method = "PCoA", distance = "bray")
p_pcoa <- plot_ordination(physeq, pcoa_bc, color = "Zone", shape = "Habitat") +
  geom_point(size = 4) +
  stat_ellipse(type = "t", linetype = 2) +
  theme_bw() +
  labs(title = "PCoA based on Bray-Curtis Dissimilarity")

ggsave("PCoA_BrayCurtis.png", p_pcoa, width = 8, height = 6, dpi = 300)
cat("\nAnalysis complete. PCoA plot saved.\n")
