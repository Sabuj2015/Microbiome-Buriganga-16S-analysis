# 03_functional_prediction.R
# This script performs statistical testing and visualization (heatmap) on 
# inferred functional profiles (e.g., from PICRUSt2).

library(dplyr)
library(tidyr)
library(pheatmap)

# Note: This script assumes you have processed your 16S data through PICRUSt2
# and have a predicted pathway abundance table (e.g., KEGG pathways).
# Because the raw PICRUSt2 output is not provided in this specific folder, 
# this script serves as a template using a placeholder data structure that 
# matches the manuscript's methodology.

# 1. Load Data
# pathway_data <- read.table("picrust2_out/pathways_out/pathway_abundance.tsv", 
#                            header = TRUE, row.names = 1, sep = "\t")
#
# For demonstration purposes, we will mock the structure based on the study design:
samples <- c(paste0(c("Deul", "Nbb", "Abb"), "S"),
             paste0(c("Bsb", "Mdc", "Krc", "Bsg", "Jjf", "Bbb"), "S"),
             paste0(c("Cmb", "Pgb", "Hnb", "Pagla", "Fatul"), "S"),
             paste0(c("Deul", "Nbb", "Abb"), "W"),
             paste0(c("Bsb", "Mdc", "Krc", "Bsg", "Jjf", "Bbb"), "W"),
             paste0(c("Cmb", "Pgb", "Hnb", "Pagla", "Fatul"), "W"))

habitat <- ifelse(grepl("W$", samples), "Water", "Sediment")

# Mock data (replace with actual pathway_data)
set.seed(42)
pathway_data <- data.frame(matrix(runif(length(samples) * 50, 100, 10000), 
                                  nrow = 50, ncol = length(samples)))
colnames(pathway_data) <- samples
rownames(pathway_data) <- paste0("KEGG_Pathway_", 1:50)

# Remove human disease and organ system categories (if mapped to higher KEGG levels)
# pathway_data <- pathway_data[!grepl("Human Diseases|Organismal Systems", rownames(pathway_data)), ]

# 2. Calculate Relative Abundance
total_abundance <- colSums(pathway_data)
rel_pathway <- sweep(pathway_data, 2, total_abundance, "/") * 100

# 3. Differential Abundance Testing (Wilcoxon test)
p_values <- apply(rel_pathway, 1, function(x) {
  water_abund <- x[habitat == "Water"]
  sed_abund <- x[habitat == "Sediment"]
  res <- wilcox.test(water_abund, sed_abund, exact = FALSE)
  return(res$p.value)
})

# Benjamini-Hochberg FDR correction
adj_p_values <- p.adjust(p_values, method = "BH")

func_diff_results <- data.frame(
  Pathway = rownames(rel_pathway),
  Mean_Water = rowMeans(rel_pathway[, habitat == "Water"]),
  Mean_Sediment = rowMeans(rel_pathway[, habitat == "Sediment"]),
  p_value = p_values,
  FDR_adjusted_p = adj_p_values
)

sig_pathways <- func_diff_results %>% filter(FDR_adjusted_p < 0.05)
cat(sprintf("Found %d functional pathways significantly different between Water and Sediment (FDR < 0.05).\n", nrow(sig_pathways)))
write.csv(func_diff_results, "Functional_Differential_Abundance.csv", row.names = FALSE)

# 4. Heatmap Generation
# Select top 30 most abundant pathways for visualization
top30_pathways <- head(rel_pathway[order(-rowMeans(rel_pathway)), ], 30)

annotation_col <- data.frame(
  Habitat = factor(habitat)
)
rownames(annotation_col) <- samples

# The manuscript states absolute predicted pathway relative abundance is plotted
# (not row-standardized), so we set scale="none".
png("Figure_6_Functional_Heatmap.png", width = 3000, height = 2400, res = 300)
pheatmap(top30_pathways,
         scale = "none",  
         cluster_rows = TRUE,
         cluster_cols = TRUE,
         clustering_distance_rows = "euclidean",
         clustering_method = "complete",
         annotation_col = annotation_col,
         show_colnames = FALSE,
         fontsize_row = 8,
         main = "Predicted KEGG Pathway Relative Abundance")
dev.off()
cat("\nFunctional heatmap generated: Figure_6_Functional_Heatmap.png\n")
