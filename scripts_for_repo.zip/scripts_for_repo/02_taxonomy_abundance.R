# 02_taxonomy_abundance.R
# This script performs taxonomic abundance analysis, differential abundance testing
# (Mann-Whitney U with Benjamini-Hochberg FDR), and generates row-standardized heatmaps.

library(dplyr)
library(tidyr)
library(pheatmap)

# 1. Load Data
otu_data <- read.csv("Buriganga_Turag_16S_OTU_Taxonomy_Counts.csv", row.names = 1)
tax_data <- otu_data[, "Taxonomy", drop = FALSE]
otu_counts <- otu_data[, -ncol(otu_data)]

# 2. Extract Genus level taxonomy
extract_genus <- function(tax_string) {
  # Assuming semicolon separated taxonomy string
  taxa <- unlist(strsplit(as.character(tax_string), ";"))
  if (length(taxa) >= 6) {
    genus <- gsub("g__", "", trimws(taxa[6]))
    if (genus == "" || is.na(genus) || genus == "unidentified") return("Unclassified")
    return(genus)
  }
  return("Unclassified")
}
otu_counts$Genus <- sapply(tax_data$Taxonomy, extract_genus)

# 3. Aggregate to Genus level
genus_counts <- otu_counts %>%
  group_by(Genus) %>%
  summarise(across(everything(), sum))

rownames(genus_counts) <- genus_counts$Genus
genus_counts <- genus_counts[, -1]

# 4. Calculate Relative Abundance
total_counts <- colSums(genus_counts)
rel_abund <- sweep(genus_counts, 2, total_counts, "/") * 100

# Keep abundant genera (e.g., mean relative abundance >= 0.1%)
mean_abund <- rowMeans(rel_abund)
top_genera <- rel_abund[mean_abund >= 0.1, ]
cat(sprintf("Retained %d genera with >= 0.1%% mean relative abundance.\n", nrow(top_genera)))

# 5. Differential Abundance Testing (Mann-Whitney U / Wilcoxon)
samples <- colnames(rel_abund)
habitat <- ifelse(grepl("W$", samples), "Water", "Sediment")

p_values <- apply(top_genera, 1, function(x) {
  water_abund <- x[habitat == "Water"]
  sed_abund <- x[habitat == "Sediment"]
  res <- wilcox.test(water_abund, sed_abund, exact = FALSE)
  return(res$p.value)
})

# Benjamini-Hochberg FDR correction
adj_p_values <- p.adjust(p_values, method = "BH")

diff_abund_results <- data.frame(
  Genus = rownames(top_genera),
  Mean_Water = rowMeans(top_genera[, habitat == "Water"]),
  Mean_Sediment = rowMeans(top_genera[, habitat == "Sediment"]),
  p_value = p_values,
  FDR_adjusted_p = adj_p_values
)

# Identify significant genera (Q < 0.05)
sig_genera <- diff_abund_results %>% filter(FDR_adjusted_p < 0.05)
cat(sprintf("Found %d genera significantly different between Water and Sediment (FDR < 0.05).\n", nrow(sig_genera)))
write.csv(diff_abund_results, "Differential_Abundance_Results.csv", row.names = FALSE)

# 6. Heatmap Generation
# Select top 50 most abundant genera for clearer visualization
top50_genera <- head(top_genera[order(-rowMeans(top_genera)), ], 50)

# Create metadata annotation for heatmap
annotation_col <- data.frame(
  Habitat = factor(ifelse(grepl("W$", samples), "Water", "Sediment")),
  Zone = factor(case_when(
    grepl("^(Deul|Nbb|Abb)", samples) ~ "Upstream",
    grepl("^(Bsb|Mdc|Krc|Bsg|Jjf|Bbb)", samples) ~ "Midstream",
    grepl("^(Cmb|Pgb|Hnb|Pagla|Fatul)", samples) ~ "Downstream"
  ), levels = c("Upstream", "Midstream", "Downstream"))
)
rownames(annotation_col) <- samples

# Generate row-standardized (z-score) heatmap with clustering on both axes
# Note: scale="row" automatically z-scores the data
png("Figure_5A_Heatmap.png", width = 3000, height = 2400, res = 300)
pheatmap(top50_genera,
         scale = "row",
         cluster_rows = TRUE,
         cluster_cols = TRUE,
         clustering_distance_rows = "euclidean",
         clustering_method = "complete",
         annotation_col = annotation_col,
         show_colnames = FALSE,
         fontsize_row = 8,
         main = "Row-standardized Genus Relative Abundance")
dev.off()
cat("\nHeatmap generated: Figure_5A_Heatmap.png\n")
