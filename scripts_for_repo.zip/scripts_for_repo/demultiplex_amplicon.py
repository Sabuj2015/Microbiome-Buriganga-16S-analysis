#!/usr/bin/env python3
"""
demultiplex_amplicon.py

Custom Python script for demultiplexing paired-end 16S rRNA amplicon sequencing data 
based on a 12-bp sample-specific barcode located at the beginning of the forward read (R1).

Requirements:
- Python 3.6+
- No external dependencies (uses standard library `gzip` and `argparse`)

Usage:
python3 demultiplex_amplicon.py -i1 Undetermined_S0_L001_R1_001.fastq.gz \
                                -i2 Undetermined_S0_L001_R2_001.fastq.gz \
                                -m mapping_file.txt \
                                -o demux_out_dir/

The mapping file should be a tab-separated text file without a header:
SampleID    BarcodeSequence
DeulS       ATGCGTACGTTA
NbbS        CGTACGTACGTC
...
"""

import argparse
import gzip
import os
import sys
from collections import defaultdict

def load_mapping(mapping_file):
    """Load barcode to sample mapping."""
    barcode_map = {}
    with open(mapping_file, 'r') as f:
        for line in f:
            if line.strip() and not line.startswith('#'):
                parts = line.strip().split('\t')
                if len(parts) >= 2:
                    sample_id = parts[0]
                    barcode = parts[1].upper()
                    if len(barcode) != 12:
                        print(f"Warning: Barcode for {sample_id} is not 12bp.", file=sys.stderr)
                    barcode_map[barcode] = sample_id
    return barcode_map

def main():
    parser = argparse.ArgumentParser(description="Demultiplex 16S paired-end FASTQ files by 12-bp barcode in R1.")
    parser.add_argument("-i1", "--input_r1", required=True, help="Input raw forward reads (FASTQ.GZ)")
    parser.add_argument("-i2", "--input_r2", required=True, help="Input raw reverse reads (FASTQ.GZ)")
    parser.add_argument("-m", "--mapping", required=True, help="Mapping file (SampleID [tab] Barcode)")
    parser.add_argument("-o", "--outdir", required=True, help="Output directory for demultiplexed files")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.outdir):
        os.makedirs(args.outdir)
        
    barcode_to_sample = load_mapping(args.mapping)
    print(f"Loaded {len(barcode_to_sample)} barcodes from mapping file.")
    
    # Open file handles for output
    out_handles = {}
    for sample in set(barcode_to_sample.values()):
        r1_path = os.path.join(args.outdir, f"{sample}_R1.fastq.gz")
        r2_path = os.path.join(args.outdir, f"{sample}_R2.fastq.gz")
        out_handles[sample] = (gzip.open(r1_path, 'wt'), gzip.open(r2_path, 'wt'))
        
    unmatched_r1_path = os.path.join(args.outdir, "Unmatched_R1.fastq.gz")
    unmatched_r2_path = os.path.join(args.outdir, "Unmatched_R2.fastq.gz")
    out_handles["Unmatched"] = (gzip.open(unmatched_r1_path, 'wt'), gzip.open(unmatched_r2_path, 'wt'))
    
    total_reads = 0
    matched_reads = 0
    
    # Process paired-end files
    with gzip.open(args.input_r1, 'rt') as f1, gzip.open(args.input_r2, 'rt') as f2:
        while True:
            # Read 4 lines per record
            id1 = f1.readline()
            if not id1: break
            seq1 = f1.readline()
            plus1 = f1.readline()
            qual1 = f1.readline()
            
            id2 = f2.readline()
            seq2 = f2.readline()
            plus2 = f2.readline()
            qual2 = f2.readline()
            
            total_reads += 1
            
            # Extract 12bp barcode from R1
            barcode = seq1[:12].upper()
            
            sample_id = "Unmatched"
            
            # Exact match (for speed, can be extended for 1 mismatch if needed)
            if barcode in barcode_to_sample:
                sample_id = barcode_to_sample[barcode]
                matched_reads += 1
                
                # Strip barcode from R1
                seq1 = seq1[12:]
                qual1 = qual1[12:]
                
            # Write to respective sample files
            out_r1, out_r2 = out_handles[sample_id]
            out_r1.write(f"{id1}{seq1}{plus1}{qual1}")
            out_r2.write(f"{id2}{seq2}{plus2}{qual2}")
            
            if total_reads % 500000 == 0:
                print(f"Processed {total_reads} read pairs...")
                
    # Close handles
    for handle_r1, handle_r2 in out_handles.values():
        handle_r1.close()
        handle_r2.close()
        
    print("\n--- Demultiplexing Summary ---")
    print(f"Total reads processed: {total_reads}")
    print(f"Reads matched to barcode: {matched_reads} ({matched_reads/total_reads*100:.2f}%)")
    print(f"Reads unmatched: {total_reads - matched_reads}")
    print("Complete.")

if __name__ == "__main__":
    main()
