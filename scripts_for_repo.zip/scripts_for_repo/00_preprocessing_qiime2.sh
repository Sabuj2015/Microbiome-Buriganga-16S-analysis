#!/bin/bash
# 00_preprocessing_qiime2.sh
# Bioinformatic pipeline for processing raw 16S rRNA gene sequences
# This script covers demultiplexing, quality control, merging, chimera removal, 
# and OTU clustering as described in the manuscript.

# Set variables
RAW_DATA_DIR="./raw_fastq"
PROCESSED_DIR="./processed_reads"
QIIME_DIR="./qiime2_output"
SILVA_CLASSIFIER="silva-138-99-nb-classifier.qza"
THREADS=16

mkdir -p $PROCESSED_DIR $QIIME_DIR

echo "1. Demultiplexing (Custom Python script placeholder)"
# Assuming the custom python script separates by 12bp barcodes
# python3 custom_demultiplex.py -i $RAW_DATA_DIR/undetermined.fastq.gz -m metadata.txt -o $PROCESSED_DIR/demux/

echo "2. Adapter Trimming with Cutadapt"
# Example loop for processing paired-end files
for f in $PROCESSED_DIR/demux/*_R1.fastq.gz; do
    r2=${f/_R1.fastq.gz/_R2.fastq.gz}
    base=$(basename $f _R1.fastq.gz)
    
    cutadapt -g Forward_Primer -G Reverse_Primer \
        -o $PROCESSED_DIR/trimmed/${base}_R1.fastq.gz \
        -p $PROCESSED_DIR/trimmed/${base}_R2.fastq.gz \
        $f $r2 > $PROCESSED_DIR/trimmed/${base}_cutadapt.log
done

echo "3. Merging paired-end reads with FLASH"
for f in $PROCESSED_DIR/trimmed/*_R1.fastq.gz; do
    r2=${f/_R1.fastq.gz/_R2.fastq.gz}
    base=$(basename $f _R1.fastq.gz)
    
    flash $f $r2 -M 250 -o ${base} -d $PROCESSED_DIR/merged/
done

echo "4. Quality filtering with Fastp (Q > 19)"
for f in $PROCESSED_DIR/merged/*.extendedFrags.fastq; do
    base=$(basename $f .extendedFrags.fastq)
    fastp -i $f -o $PROCESSED_DIR/filtered/${base}_filtered.fastq \
          -q 19 -u 50 -n 0 -l 150 --thread $THREADS
done

echo "5. Chimera removal with VSEARCH"
for f in $PROCESSED_DIR/filtered/*_filtered.fastq; do
    base=$(basename $f _filtered.fastq)
    vsearch --uchime_denovo $f \
            --nonchimeras $PROCESSED_DIR/nonchimeric/${base}_clean.fastq
done

echo "6. Import into QIIME2"
qiime tools import \
  --type 'SampleData[SequencesWithQuality]' \
  --input-path $PROCESSED_DIR/nonchimeric/ \
  --input-format CasavaOneEightSingleLanePerSampleDirFmt \
  --output-path $QIIME_DIR/demux_clean.qza

echo "7. Denoising and OTU inference with DADA2 (QIIME2)"
qiime dada2 denoise-single \
  --i-demultiplexed-seqs $QIIME_DIR/demux_clean.qza \
  --p-trunc-len 0 \
  --p-n-threads $THREADS \
  --o-representative-sequences $QIIME_DIR/rep-seqs.qza \
  --o-table $QIIME_DIR/table.qza \
  --o-denoising-stats $QIIME_DIR/dada2-stats.qza

echo "8. Assign Taxonomy (SILVA 138)"
qiime feature-classifier classify-sklearn \
  --i-classifier $SILVA_CLASSIFIER \
  --i-reads $QIIME_DIR/rep-seqs.qza \
  --o-classification $QIIME_DIR/taxonomy.qza

echo "9. Build Phylogenetic Tree"
qiime phylogeny align-to-tree-mafft-fasttree \
  --i-sequences $QIIME_DIR/rep-seqs.qza \
  --o-alignment $QIIME_DIR/aligned-rep-seqs.qza \
  --o-masked-alignment $QIIME_DIR/masked-aligned-rep-seqs.qza \
  --o-tree $QIIME_DIR/unrooted-tree.qza \
  --o-rooted-tree $QIIME_DIR/rooted-tree.qza

echo "Pipeline complete. Ready for downstream statistical analysis in R."
