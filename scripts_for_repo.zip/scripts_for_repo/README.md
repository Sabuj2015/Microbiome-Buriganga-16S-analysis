# Buriganga-Turag 16S Microbiome Analysis

This repository contains the R and Python scripts used for the statistical and bioinformatic analyses presented in the manuscript detailing the microbiome of the Buriganga and Turag rivers.

## Scripts Overview

0. **`demultiplex_amplicon.py`**
   - Custom Python script for demultiplexing paired-end 16S rRNA amplicon sequencing data based on a 12-bp sample-specific barcode located at the beginning of the forward read (R1).
   - This script satisfies the reviewer request (Comment 6) for providing the custom demultiplexing script.

0b. **`00_preprocessing_qiime2.sh`**
   - Bash script detailing the initial bioinformatics pipeline described in the manuscript.
   - Covers demultiplexing (custom script placeholder), adapter trimming (Cutadapt), read merging (FLASH), quality filtering (Fastp), chimera removal (VSEARCH), and OTU inference/taxonomy assignment (QIIME2/DADA2 with SILVA 138).

1. **`01_alpha_beta_diversity.R`**
   - Calculates alpha diversity indices (Chao1, Shannon, Simpson, etc.).
   - Performs Kruskal-Wallis tests and Dunn's post-hoc tests for group comparisons.
   - Computes Bray-Curtis dissimilarity matrices.
   - Runs PERMDISP (dispersion) and PERMANOVA (community structure differences).
   - Generates Principal Coordinates Analysis (PCoA) plots.

2. **`02_taxonomy_abundance.R`**
   - Aggregates OTU count data to the Genus level.
   - Calculates relative abundance.
   - Performs differential abundance testing between Habitats using Mann-Whitney U / Wilcoxon tests with Benjamini-Hochberg FDR correction.
   - Generates row-standardized heatmaps with hierarchical clustering (via `pheatmap`).

3. **`03_functional_prediction.R`**
   - Script template to process and visualize PICRUSt2 functional predictions (e.g., KEGG pathway relative abundances).
   - Performs differential functional abundance testing and visualization.

4. **`04_core_microbiome_upset.py`**
   - Python script utilizing `pandas` and `matplotlib` to generate the UpSet plot for the core microbiome.
   - Calculates intersections of OTU presence/absence across all 6 Zone × Habitat combinations.

## Requirements
- **R (>= 4.0.3)**: `phyloseq`, `vegan`, `ggplot2`, `dunn.test`, `dplyr`, `tidyr`, `pheatmap`
- **Python (>= 3.8)**: `pandas`, `numpy`, `matplotlib`

## Usage
Ensure the `Buriganga_Turag_16S_OTU_Taxonomy_Counts.csv` data file is in the same directory before executing the scripts.
