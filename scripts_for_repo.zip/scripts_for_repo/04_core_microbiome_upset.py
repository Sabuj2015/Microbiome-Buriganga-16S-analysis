"""
Generate UpSet plot for OTU membership across 6 zone × habitat groups.
Outputs: Additional_File_UpSet_CoreMicrobiome.png and .tiff
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from itertools import product

# ── 1. Load OTU table ──────────────────────────────────────────────────────────
df = pd.read_csv('Buriganga_Turag_16S_OTU_Taxonomy_Counts.csv')

# ── 2. Define groups ───────────────────────────────────────────────────────────
groups = {
    'Up-Sed':   ['DeulS', 'NbbS',  'AbbS'],
    'Mid-Sed':  ['BsbS',  'MdcS',  'KrcS',  'BsgS',  'JjfS',  'BbbS'],
    'Down-Sed': ['CmbS',  'PgbS',  'HnbS',  'PaglaS','FatulS'],
    'Up-Wat':   ['DeulW', 'NbbW',  'AbbW'],
    'Mid-Wat':  ['BsbW',  'MdcW',  'KrcW',  'BsgW',  'JjfW',  'BbbW'],
    'Down-Wat': ['CmbW',  'PgbW',  'HnbW',  'PaglaW','FatulW'],
}

presence = {}
for g, cols in groups.items():
    presence[g] = (df[cols].sum(axis=1) > 0).values

group_names = list(groups.keys())
n_groups = len(group_names)
n_otus   = len(df)

# ── 3. Compute intersections ───────────────────────────────────────────────────
all_intersections = []
for bits in product([0, 1], repeat=n_groups):
    if sum(bits) == 0:
        continue
    mask = np.ones(n_otus, dtype=bool)
    for i, b in enumerate(bits):
        if b == 1:
            mask &= presence[group_names[i]]
        else:
            mask &= ~presence[group_names[i]]
    count = mask.sum()
    if count > 0:
        all_intersections.append((bits, count))

all_intersections.sort(key=lambda x: -x[1])
top = all_intersections[:30]

# ── 4. Colour scheme ───────────────────────────────────────────────────────────
colors = {
    'Up-Sed':   '#8B4513',
    'Mid-Sed':  '#CD853F',
    'Down-Sed': '#DEB887',
    'Up-Wat':   '#1B4F8A',
    'Mid-Wat':  '#3A85C8',
    'Down-Wat': '#90C8E8',
}

def bar_color(bits):
    water_on = any(bits[i] for i, g in enumerate(group_names) if 'Wat' in g)
    sed_on   = any(bits[i] for i, g in enumerate(group_names) if 'Sed' in g)
    if water_on and sed_on:
        return '#6A5ACD'
    elif water_on:
        return '#3A85C8'
    else:
        return '#8B4513'

# ── 5. Figure layout ───────────────────────────────────────────────────────────
n_bars = len(top)
fig = plt.figure(figsize=(20, 9))
fig.patch.set_facecolor('white')

# Axes in normalised figure coordinates
# [left, bottom, width, height]
LEFT   = 0.20    # leave room on left for group labels + set sizes
RIGHT  = 0.01
BOTTOM = 0.04
TOP    = 0.10
GAP    = 0.03
MAT_H  = 0.30
BAR_H  = 0.52

ax_bar = fig.add_axes([LEFT, BOTTOM + MAT_H + GAP, 1 - LEFT - RIGHT, BAR_H])
ax_mat = fig.add_axes([LEFT, BOTTOM,               1 - LEFT - RIGHT, MAT_H])

bar_width = 0.65
xs = np.arange(n_bars)

# ── Bar chart ─────────────────────────────────────────────────────────────────
bar_colors = [bar_color(bits) for bits, _ in top]
counts     = [c for _, c in top]

ax_bar.bar(xs, counts, width=bar_width, color=bar_colors,
           edgecolor='white', linewidth=0.4, zorder=3)

for x, c in zip(xs, counts):
    ax_bar.text(x, c + max(counts) * 0.012, f'{c:,}',
                ha='center', va='bottom', fontsize=6, fontweight='bold',
                color='#333333')

ax_bar.set_xlim(-0.6, n_bars - 0.4)
ax_bar.set_ylim(0, max(counts) * 1.14)
ax_bar.set_ylabel('OTU count', fontsize=11, labelpad=8)
ax_bar.set_xticks([])
ax_bar.spines['top'].set_visible(False)
ax_bar.spines['right'].set_visible(False)
ax_bar.spines['bottom'].set_visible(False)
ax_bar.yaxis.grid(True, linestyle='--', alpha=0.45, zorder=0)
ax_bar.set_axisbelow(True)
ax_bar.tick_params(axis='y', labelsize=9)

legend_patches = [
    mpatches.Patch(color='#8B4513', label='Sediment-only'),
    mpatches.Patch(color='#3A85C8', label='Water-only'),
    mpatches.Patch(color='#6A5ACD', label='Shared (sediment + water)'),
]
ax_bar.legend(handles=legend_patches, fontsize=9, loc='upper right',
              framealpha=0.9, edgecolor='#CCCCCC')

# Title
fig.suptitle(
    'UpSet Plot: OTU membership across zone × habitat combinations\n'
    'Buriganga–Turag River System  |  January 2023  |  top 30 intersections',
    fontsize=12, fontweight='bold', y=0.99, color='#222222'
)

# ── Matrix panel ──────────────────────────────────────────────────────────────
y_pos = {g: n_groups - 1 - i for i, g in enumerate(group_names)}

for xi, (bits, _) in enumerate(top):
    active = [group_names[i] for i, b in enumerate(bits) if b == 1]
    for g in group_names:
        ax_mat.scatter(xi, y_pos[g], s=100, color='#DEDEDE', zorder=2, linewidths=0)
    for g in active:
        ax_mat.scatter(xi, y_pos[g], s=100, color=colors[g], zorder=4, linewidths=0)
    if len(active) > 1:
        ys = sorted([y_pos[g] for g in active])
        ax_mat.plot([xi, xi], [ys[0], ys[-1]], color='#555555', lw=1.6, zorder=3)

ax_mat.set_xlim(-0.6, n_bars - 0.4)
ax_mat.set_ylim(-0.6, n_groups - 0.4)
ax_mat.set_xticks([])
ax_mat.set_yticks([])
for sp in ax_mat.spines.values():
    sp.set_visible(False)
ax_mat.tick_params(left=False)

# Alternating row shading
for i, g in enumerate(group_names):
    y = y_pos[g]
    if i % 2 == 0:
        ax_mat.axhspan(y - 0.5, y + 0.5, color='#F5F5F5', zorder=0)

# ── Left panel: group labels (coloured) + set sizes ───────────────────────────
# We draw this directly in figure coordinates using fig.text, anchored to
# the matrix rows projected into figure space.
# Compute figure-space y for each matrix row:
mat_ax_bottom = BOTTOM
mat_ax_top    = BOTTOM + MAT_H
row_height    = MAT_H / n_groups

for i, g in enumerate(group_names):
    # centre of this row in figure coords
    row_idx  = y_pos[g]              # 0 = bottom row, 5 = top row
    fig_y    = mat_ax_bottom + (row_idx + 0.5) * row_height

    total    = int(presence[g].sum())

    # Group label – right-aligned at x=0.01 to 0.12
    fig.text(0.125, fig_y, g,
             ha='right', va='center', fontsize=10.5,
             color=colors[g], fontweight='bold')

    # Set size – left of the matrix, right-aligned just before LEFT
    fig.text(LEFT - 0.005, fig_y, f'{total:,}',
             ha='right', va='center', fontsize=9,
             color=colors[g], fontweight='bold')

# Column header for set sizes
fig.text(LEFT - 0.005,
         mat_ax_top + 0.005,
         'Set\nsize',
         ha='right', va='bottom', fontsize=8, color='#555555', style='italic')

# ── Save ──────────────────────────────────────────────────────────────────────
for ext in ('png', 'tiff'):
    out = f'Additional_File_UpSet_CoreMicrobiome.{ext}'
    plt.savefig(out, dpi=300, bbox_inches='tight', facecolor='white')
    print(f'Saved: {out}')

print('\n=== Set sizes ===')
for g in group_names:
    print(f'  {g}: {int(presence[g].sum()):,}')

print('\n=== Top 10 intersections ===')
for bits, count in top[:10]:
    names = [group_names[i] for i, b in enumerate(bits) if b == 1]
    print(f'  {" ∩ ".join(names)}: {count:,}')
